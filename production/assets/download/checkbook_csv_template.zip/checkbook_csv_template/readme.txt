1. Please DO NOT modify the header.
2. First name and last name have to be more than two characters.
3. If you fill out a business name, you can skip first name and last name.
4. Check number is optional.

Example
First Name,Last Name,Business Name,Address,Amount,Check No,Description
Anne, Brown, , anne.brown@checkbook.io, 50.00,1001,send a check to individual
,,Some Company Inc., hello@checkbook.io, 1.00,1002,send a check to business